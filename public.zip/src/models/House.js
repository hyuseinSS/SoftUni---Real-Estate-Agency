const mongoose = require('mongoose');





const houseSchema = new mongoose.Schema({
    // ⦁	Name - string (required),
    name: {
        type: String,
        required: true,
    },
    // ⦁	Type - string (“Apartment”, “Villa”, “House”) required,
    type: {
        type: String,
        required: true,
    },
    // ⦁	Year - number (required),
    year: {
        type: Number,
        required: true,
    },
    // ⦁	City – string (required),
    city: {
        type: String,
        required: true,
    },
    // ⦁	Home Image - string (required),
    image: {
        type: String,
        required: true,
    },
    // ⦁	Property Description - string (required),
    description: {
        type: String,
        required: true,
    },
    // ⦁	Available pieces - number(required)
    availability: {
        type: Number,
        required: true
    },
    // ⦁	Rented a home - a collection of Users (reference to the User model)
    rentedBy: [
        {
            maxLength: this.availability,
            type: mongoose.Types.ObjectId,
            ref: "User"
        }
    ],
    // ⦁	Owner - object Id (reference to the User model)
    owner: {
        type: mongoose.Types.ObjectId,
        ref: "User"
    }
})


const House = mongoose.model('House', houseSchema);

module.exports = House