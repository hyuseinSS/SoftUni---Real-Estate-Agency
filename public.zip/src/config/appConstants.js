
exports.sessionName  = 'session'
exports.secret = '123kj12u3h12kj31n2kj321'
exports.saltRounds = 10;